# PISA Data
## by Osama Taha

## Dataset

This dataset containing PISA survey of students' skills and attitude taking into concideration the surrounding circumstances.
It consists of 485490 rows and 636 columns and most (if not all) of the data types are floats, integers or objects.


## What are the main features of interest in my dataset?

    Participating countries distribution.
    The effect of gender on participation.
    Do most of the students own a computer or not ?

    The effect of gender on international grades.. Which gender has higher grades?
    The effect of both Tuancy variables on international grades.
    Does the country of the student affect his grade ?

    The effect of mother & father job status on Truancy
    The effect of both Possessions variables on international grades.
    Is there a relation between Attitude variables & grades ?


## Key Insights for Presentation

    Top 3 countries in participation are Maxico, Italy & Spain and the least country is Liechtenstein.
    Female-gender's participation is slightly greater than the male's.
    while studing students possessions, I found that most of students own a computer.

    Gender & County names have no effect in International Grades.
    After studying two tuancy variables, I found that Tuancy variables have no effect on Grades

    The effect of mother & father job status on Truancy: Data need more investigation as there are many null values.
    After more studying on Possessions, I found that Poss. variables have no effect on Grades.
    Regarding Student Attitude, I found that it has no effect on Grades.
